# creating database Bank
create database sqlproject;

# selecting Bank database
use sqlproject;

# checking if we got all of our tables
show tables;

# let's check what's inside the data
select*from activeid limit 10;
select * from bank_churn limit 10;
select * from creditcard limit 10;
select * from customerinfo limit 10;
select * from exitcustomer limit 10;
select * from genderid limit 10;
select * from geography limit 10;

# let's create a full_view of all these tables so we do our analysis even better

CREATE VIEW full_view AS 
SELECT 
    ci.customerid,
    ci.surname,
    ci.age,
    ci.genderid,
    ci.estimatedsalary,
    ci.geographyid,
    ci.bank_doj,
    bc.CreditScore,
    bc.Tenure,
    bc.Balance,
    bc.NumOfProducts,
    bc.HasCrCard,
    bc.IsActiveMember,
    bc.Exited,
    ac.ActiveID,
    ac.ActiveCategory,
    cc.CreditID,
    cc.Category,
    gg.GeographyLocation,
    g.GenderCategory,
    ec.ExitID,
    ec.ExitCategory
FROM 
    customerinfo ci
left JOIN 
    bank_churn bc ON ci.customerid = bc.customerid
left JOIN 
    activeid ac ON bc.IsActiveMember = ac.activeid
left JOIN 
    creditcard cc ON bc.HasCrCard = cc.creditid
left JOIN 
    exitinfo ec ON bc.exited = ec.exitid
left JOIN 
    genderid g ON ci.genderid = g.genderid
left JOIN 
    geography gg ON ci.geographyid = gg.geographyid;

-- DROP VIEW IF EXISTS full_view;

-- ALTER TABLE customerinfo
-- CHANGE Bank DOJ bank_doj TEXT;


/* Q1) What is the distribution of account balance across different regions?


*/
select * from bank_churn limit 1;

# Approach 1
select distinct
GeographyLocation,
round(sum(balance) over(partition by GeographyLocation),2) as balance
from full_view;

# Approach 2
select distinct
g.GeographyLocation,
round(sum(bc.balance) over(partition by g.GeographyLocation),2) as balance
from customerinfo c 
left join bank_churn bc on c.CustomerId = bc.CustomerId
left join geography g on c.geographyid = g.GeographyID;

# Q2) Identify the top 5 customers with the highest Salary

select
CustomerId as Customer_Id, surname as Customer_Name,
max(estimatedsalary) as Salary 
from full_view
group by 1, 2
order by Salary desc
limit 5;

# Q3) Calculate the average number of products used by customers who have a credit card.

SELECT DISTINCT
    ROUND(AVG(bc.NumOfProducts) OVER (), 2) AS AvgProducts
FROM
    customerinfo c
LEFT JOIN
    bank_churn bc ON c.CustomerId = bc.CustomerId
LEFT JOIN
    creditcard cc ON bc.CustomerId = c.CustomerId AND bc.HasCrCard = 1;

select
Category,
avg(NumOfProducts) avg_no_of_products,
count(customerId) count_of_customers
from full_view
group by category;

# Q4) Determine the churn rate by gender for the most recent year in the dataset.
select sum(bc.Exited), ci.GenderID, bc.Tenure 
from customerinfo ci
join bank_churn bc
on ci.CustomerId = bc.CustomerId
group by ci.GenderID, bc.Tenure
order by ci.genderID;


# Q5) Compare the average credit score of customers who have exited and those who remain.
select * from full_view limit 4;

select exitId,avg(CreditScore) 
avg_credit_score from full_view
group by exitID;

# Q6) Which gender has a higher average estimated salary, and how does it relate to the number of active accounts? 

select genderid, gendercategory
,avg(estimatedsalary) avg_estimated_salary, count(isactivemember) as numactiveaccounts
from full_view
where activeid = 1
group by genderid, gendercategory;

# Q7) Segment the customers based on their credit score and identify the segment with the highest exit rate.

select * from full_view limit 4;

-- CreditScore: A numerical representation of the customer's creditworthiness.
-- Credit score: 
-- Excellent: 800–850
-- Very Good: 740–799
-- Good: 670–739
-- Fair: 580–669
-- Poor: 300–579

with cte as (select customerid, creditscore, exited,
case 
when creditscore >= 800 and creditscore <= 850 then 'excellent'
when creditscore >= 740 and creditscore <= 799 then 'verygood'
when creditscore >= 670 and creditscore <= 739 then 'good'
when creditscore >= 580 and creditscore <= 669 then 'fair'
else 'poor' 
end as credit_type
from full_view
)

select credit_type, count(distinct customerid) as customer_count
from cte
where exited = 1
group by credit_type
order by count(distinct customerid) desc;


# Q8) Find out which geographic region has the highest number of active customers with a tenure greater than 5 years. 

select distinct GeographyLocation,
count(customerid) as active_customers
from full_view
where activeID = 1 and Tenure > 5
group by GeographyLocation ;

# Q9) What is the impact of having a credit card on customer churn, based on the available data?

select * from full_view limit 1;

with churndata as (
select
HasCrCard,
count(*) as total_customers,
sum(case when exitid = '1' then 1 else 0 end) as churned_customers
from full_view
group by HasCrCard
)

select
HasCrCard,
total_customers,
churned_customers,
churned_customers/total_customers as churn_rate
from churndata;


# Q10) For customers who have exited, what is the most common number of products they had used?

select * from full_view limit 10;

select numofproducts, count(numofproducts) as productcount
from full_view
where exited = 1
group by numofproducts
order by productcount desc
;


# Q11) Examine the trend of customer exits over time and identify any seasonal patterns (yearly or monthly).
# Prepare the data through SQL and then visualize it.

select * from full_view 
where exitid = '1' and datediff(bank_doj, tenure);

# Q12) Analyze the relationship between the number of products and the account balance for customers who have exited.

select
NumOfProducts, 
round(sum(Balance),2) as Sum_Balance,
count(customerID) as CustomerCount
from full_view
where exitid = 1
group by NumOfProducts
order by NumOfProducts;

# Q13) Identify any potential outliers in terms of spend among customers who have remained with the bank.

select * from full_view 
where exitid = 0;

# Q15) Using SQL, write a query to find out the gender-wise average income of males and females in each geography id. 
# Also, rank the gender according to the average value.

select
gendercategory,
geographyid,
avg(estimatedsalary) as avg_salary,
rank() over (partition by geographyid order by avg(estimatedsalary) desc) as gender_rank
from
full_view
group by
gendercategory, geographyid
order by
geographyid, gender_rank;

# Q16)Using SQL, write a query to find out the average tenure of the people who have exited in each age bracket
# (18-30, 30-50, 50+).

select * from full_view limit 10;

select
case
    when age between 18 and 30 then '18-30'
    when age between 31 and 50 then '31-50'
    when age >= 51 then '50+'
  end as age_bracket,
avg(Tenure) AS avg_tenure
from full_view
where exitid = 1
group by age_bracket
order by age_bracket;

# Q17) Is there any direct correlation between salary and balance of the customers? And is it different for people who have exited or not?


# Q18)  Is there any correlation between salary and Credit score of customers?


# Q19) Rank each bucket of credit score as per the number of customers who have churned the bank.

SELECT segments, sum(Exited) FROM bank_churn
group by segments
;

# Q20) According to the age buckets find the number of customers who have a credit card. 
# Also retrieve those buckets who have lesser than average number of credit cards per bucket.

select * from full_view limit 3;

with agebuckets as (
  select
case
when age between 18 and 30 then '18-30'
when age between 31 and 50 then '31-50'
when age >= 51 then '50+'
end as age_bucket,
count(distinct customerid) as num_customers,
avg(case when hascrcard = 1 then 1 else 0 end) as avg_credit_cards
from full_view
group by age_bucket
)
select
age_bucket,
num_customers,
avg_credit_cards
from agebuckets
where avg_credit_cards < (select avg(avg_credit_cards) from agebuckets);

# Q21) Rank the Locations as per the number of people who have churned the bank and average balance of the customers.
select * from full_view limit 10;

with cust_count as
(
select
geographylocation,
count(customerid) as customer_count,
avg(balance) as avg_balance
from full_view
where exitid = 1
group by geographylocation
)

select
geographylocation,
customer_count,
round(avg_balance,0) as average_balance,
rank() over(order by customer_count desc) as rnk
from cust_count;

select * from full_view limit 12;






